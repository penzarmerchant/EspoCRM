/************************************************************************
 * This file is part of EspoCRM.
 *
 * EspoCRM - Open Source CRM application.
 * Copyright (C) 2014-2023 Yurii Kuznietsov, Taras Machyshyn, Oleksii Avramenko
 * Website: https://www.espocrm.com
 *
 * EspoCRM is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * EspoCRM is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with EspoCRM. If not, see http://www.gnu.org/licenses/.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "EspoCRM" word.
 ************************************************************************/

Espo.define('demo:views/login', 'view', function (Dep) {

    return Dep.extend({

        template: 'demo:login',

        language: 'en_US',

        languageList: [],

        languageLabels: {},

        views: {
            footer: {
                el: 'body > footer',
                view: 'views/site/footer'
            },
        },

        events: {
            'submit #login-form': function (e) {
                e.preventDefault();

                this.login();
            },
            'keydown': function (e) {
                if (Espo.Utils.getKeyFromKeyEvent(e) === 'Control+Enter') {
                    e.preventDefault();

                    this.login();
                }
            },
        },

        data: function () {
            return {
                logoSrc: this.getLogoSrc(),
                messageLeftMargin: this.getMessageLeftMargin()
            };
        },

        getLogoSrc: function () {
            return this.getBasePath() +
                (this.getConfig().get('logoSrc') || 'client/img/logo.svg');
        },

        //demo
        getCurrentLanguage: function() {
            let lang = null;

            if (window.location.search.indexOf('l=') > 0) {
                lang = window.location.search.substr(window.location.search.indexOf('l=')+2, 5);
            } else {
                lang = navigator.language || navigator.userLanguage;
                lang = lang.replace('-', '_');
            }

            if (!lang) {
                lang = this.getConfig().get('defaultLanguage') || 'en_US';
            }

            return lang;
        },

        setup: function () {
            Dep.prototype.setup.call(this);

            this.loadLanguageList();
        },

        afterRender: function () {
            this.$submit = this.$el.find('#btn-login');

            if ($('#field-language').html() == '') {
                this.buildLanguageList();
            }
        },

        loadLanguageList: function () {
            let self = this;
            let language = this.getCurrentLanguage();

            $.ajax({
                url: '../../?entryPoint=demoLanguageList&l=' + language,
                type: 'GET',
                dataType: 'JSON',
                success: function (data) {
                    if (data.success) {
                        self.language = data.language || 'en_US';
                        self.languageList = data.list || [];
                        self.languageLabels = data.labels || {};

                        self.buildLanguageList();
                    }
                },
            });
        },

        buildLanguageList: function() {
            let buildLangList = new Array();

            for (var langIndex in this.languageList) {
                var langValue = this.languageList[langIndex];
                buildLangList[langValue] = this.languageLabels[langValue] || langValue;
            }

            this.buildLanguageSelectOptions(buildLangList, this.language);
        },

        buildLanguageSelectOptions: function(langList, selectedItem) {
            $('#field-language').text('');

            for (var langIndex in langList) {
                var langValue = langList[langIndex];
                var selected = (langIndex == selectedItem) ? ' selected ': '';

                $('#field-language').append('<option value="'+langIndex+'" '+selected+'>'+ langValue+'</oprtion>');
            }
        },
        //END: demo

        login: function () {
            this.gtag();

            let userName = $('#field-userName').val();
            let trimmedUserName = userName.trim();

            if (trimmedUserName !== userName) {
                $('#field-userName').val(trimmedUserName);

                userName = trimmedUserName;
            }

            let password = $('#field-password').val();

            //demo
            let language = $("#field-language").val() || 'en_US';
            //END: demo

            let $submit = this.$el.find('#btn-login');

            if (userName === '') {
                this.isPopoverDestroyed = false;

                let $el = $("#field-userName");

                let message = this.getLanguage().translate('userCantBeEmpty', 'messages', 'User');

                $el
                    .popover({
                        placement: 'bottom',
                        container: 'body',
                        content: message,
                        trigger: 'manual',
                    })
                    .popover('show');

                let $cell = $el.closest('.form-group');

                $cell.addClass('has-error');

                $el.one('mousedown click', () => {
                    $cell.removeClass('has-error');

                    if (this.isPopoverDestroyed) {
                        return;
                    }

                    $el.popover('destroy');

                    this.isPopoverDestroyed = true;
                });

                return;
            }

            this.disableForm();

            Espo.Ui.notify(this.translate('pleaseWait', 'messages'));

            try {
                var authString = Base64.encode(userName  + ':' + password);
            }
            catch (e) {
                Espo.Ui.error(this.translate('Error') + ': ' + e.message, true);

                this.undisableForm();

                throw e;
            }

            Espo.Ajax
                .getRequest('App/user', null, {
                    login: true,
                    headers: {
                        'Authorization': 'Basic ' + authString,
                        'Espo-Authorization': authString,
                        'Espo-Authorization-By-Token': false,
                        'Espo-Authorization-Create-Token-Secret': true,
                    },
                })
                .then(data => {
                    this.notify(false);

                    //demo
                    let link = '?l=' + language;

                    let getParam = window.location.search.substr(1);

                    if (getParam) {
                        getParam.split('&').forEach(function(item) {
                            tmp = item.split("=");
                            if (~['r'].indexOf(tmp[0])) {
                                link += '&' + item;
                            }
                        });
                    }

                    let hashParam = window.location.hash.substr(1);
                    if (hashParam) {
                        link += '#' + hashParam;
                    }

                    window.history.replaceState(data, "Lang", link);
                    //END: demo

                    this.trigger('login', userName, data);
                })
                .catch(xhr => {
                    this.undisableForm();

                    if (xhr.status === 401) {
                        let data = xhr.responseJSON || {};

                        let statusReason = xhr.getResponseHeader('X-Status-Reason');

                        if (statusReason === 'second-step-required') {
                            xhr.errorIsHandled = true;

                            this.onSecondStepRequired(userName, password, data);

                            return;
                        }

                        this.onWrongCredentials();
                    }
                });
        },

        gtag: function () {
            let serverName = this.getConfig().get('demoServerName') || 'us';

            if (typeof dataLayer === 'undefined') {
                return;
            }

            if (dataLayer) {
                dataLayer.push({'event': 'demo_' + serverName});
            }
        },

        disableForm: function () {
            this.$submit.addClass('disabled').attr('disabled', 'disabled');
        },

        undisableForm: function () {
            this.$submit.removeClass('disabled').removeAttr('disabled');
        },

        onSecondStepRequired: function (userName, password, data) {
            let view = data.view || 'views/login-second-step';

            this.trigger('redirect', view, userName, password, data);
        },

        onWrongCredentials: function () {
            let cell = $('#login .form-group');

            cell.addClass('has-error');

            this.$el.one('mousedown click', () => {
                cell.removeClass('has-error');
            });

            Espo.Ui.error(this.translate('wrongUsernamePasword', 'messages', 'User'));
        },

        showPasswordChangeRequest: function () {
            Espo.Ui.notify(this.translate('pleaseWait', 'messages'));

            this.createView('passwordChangeRequest', 'views/modals/password-change-request', {
                url: window.location.href,
            }, (view) => {
                view.render();

                Espo.Ui.notify(false);
            });
        },

        getMessageLeftMargin: function () {
            let theme = this.getConfig().get('theme') ?? 'HazyblueVertical';

            switch (theme) {
                case 'DarkVertical':
                case 'EspoVertical':
                case 'SakuraVertical':
                case 'VioletVertical':
                    return -210;
                    break;
            }

            return 0;
        },

    });

});
